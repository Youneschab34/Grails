package grails.coin.coin

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class TestServiceSpec extends Specification implements ServiceUnitTest<TestService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
