package grails.coin.coin.Dto

class AnnonceDto {
    public Long annonceId
    public String title
    public String subTitle
    public String description
    public Float price
    public Boolean status
    public Date dateCreated
    public Date lastUpdated
    public List illustrations
}