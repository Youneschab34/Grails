package grails.coin.coin.Dto

class UserDto {
    public Long userId
    public String username
    public String password;
    public String role
}